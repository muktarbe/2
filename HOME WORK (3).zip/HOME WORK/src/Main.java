import org.w3c.dom.ls.LSOutput;

import java.nio.file.attribute.UserDefinedFileAttributeView;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public void main(String[] args) {

        Programmer obj1 = new Programmer ("Maks", "Brain",1);
        Dancer obj2 = new Dancer("Monika", "Stars",2);
        Simger.Singer obj3 = new Simger.Singer("David", "On the Galaxy",3);
        obj1.toString();
        obj2.toString();
        obj3.toString();
        System.out.println(obj1.toString());
        obj1.pacan();
        System.out.println();
        System.out.println(obj2.toString());
        obj2.devochka();
        System.out.println();
        System.out.println(obj3.toString());
        obj3.pacan2();

    }
}
